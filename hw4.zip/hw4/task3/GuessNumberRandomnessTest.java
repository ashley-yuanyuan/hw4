import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class GuessNumberRandomnessTest {

    @Test
    public void testRandomness() {

        Map<Integer, Integer> frequencyMap = new HashMap<>();

        Random rnd = new Random(0);

        // run 30,000
        for (int i = 0; i < 30000; i++) {
            String userInput = "1\n2\n3\n4\n5\n";
            System.setIn(new ByteArrayInputStream(userInput.getBytes()));

            int generatedNumber =  GuessNumber.guessingNumberGame(rnd);

            frequencyMap.put(generatedNumber, frequencyMap.getOrDefault(generatedNumber, 0) + 1);
        }


        int expectedFrequency = 300; // 30000 / 100
        for (int i = 1; i <= 100; i++) {
            int frequency = frequencyMap.getOrDefault(i, 0);
            assertTrue(frequency >= expectedFrequency * 0.5 && frequency <= expectedFrequency * 1.5);
        }
    }
}

