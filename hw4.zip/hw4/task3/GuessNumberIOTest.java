import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Random;


import org.junit.jupiter.api.Test;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

public class GuessNumberIOTest {

    public final ByteArrayOutputStream outputStream  = new ByteArrayOutputStream();

    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outputStream));
    }

    @AfterEach
    public void TearDown() {
        System.setOut(System.out);
    }


    //number is 86 when seed is 1

    @Test
    public void testGuessWrongAllGreaterThan() {
        Random rand = new Random(1); //number is 86

        String input = "1\n2\n3\n4\n5\n";
        String expected = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
                "Guess the number: The number is greater than 1\n" +
                "Guess the number: The number is greater than 2\n" +
                "Guess the number: The number is greater than 3\n" +
                "Guess the number: The number is greater than 4\n" +
                "Guess the number: The number is greater than 5\n" +
                "You have exhausted 5 trials.\n" +
                "The number was 86\n";

        System.setIn(new ByteArrayInputStream(input.getBytes()));
        GuessNumber.guessingNumberGame(rand);
        assertEquals(expected, outputStream.toString());
    }


    //why failure: program is not printing the last line  "Guess the number: The number is less than 200\n", could be something
    //to do with the less than comparison on the last try
    //fault: the underlying fault could be that when printing "less than", we skipped the last guess due to incorrect operations such
    //as using less than instead of less than equals, or subtracting one,such that we skip the last guess when printing out the messages.

    @Test
    public void testGuessWrongLessThanCorrect() {
        Random rand = new Random(1); //number is 86

        String input = "87\n88\n100\n90\n99\n";
        String expected = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
                "Guess the number: The number is less than 87\n" +
                "Guess the number: The number is less than 88\n" +
                "Guess the number: The number is less than 100\n" +
                "Guess the number: The number is less than 90\n" +
                "Guess the number: The number is less than 99\n" +
                "You have exhausted 5 trials.\n" +
                "The number was 86\n";

        System.setIn(new ByteArrayInputStream(input.getBytes()));
        GuessNumber.guessingNumberGame(rand);
        assertEquals(expected, outputStream.toString());
    }

    @Test
    public void testGuessFourthGreaterThanInput() {
        Random rand = new Random(1); //number is 86

        String input = "87\n88\n100\n90\n20\n";
        String expected = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
                "Guess the number: The number is less than 87\n" +
                "Guess the number: The number is less than 88\n" +
                "Guess the number: The number is less than 100\n" +
                "Guess the number: The number is less than 90\n" +
                "Guess the number: The number is greater than 20\n" +
                "You have exhausted 5 trials.\n" +
                "The number was 86\n";

        System.setIn(new ByteArrayInputStream(input.getBytes()));
        GuessNumber.guessingNumberGame(rand);
        assertEquals(expected, outputStream.toString());
    }


    @Test
    public void testGuessRightGuessOutputsRight() {
        Random rand = new Random(1); //number is 86

        String input = "86\n";
        String expected = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
                "Guess the number: Congratulations! You guessed the number.\n";


        System.setIn(new ByteArrayInputStream(input.getBytes()));
        GuessNumber.guessingNumberGame(rand);
        assertEquals(expected, outputStream.toString());
    }

    @Test
    public void testGuessRightSecondGuess() {
        Random rand = new Random(1); //number is 86

        String input = "85\n86\n";
        String expected = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
                "Guess the number: The number is greater than 85\n" +
                "Guess the number: Congratulations! You guessed the number.\n";


        System.setIn(new ByteArrayInputStream(input.getBytes()));
        GuessNumber.guessingNumberGame(rand);
        assertEquals(expected, outputStream.toString());
    }

    @Test
    public void testGuessRightThirdGuess() {
        Random rand = new Random(1); //number is 86

        String input = "84\n85\n86\n";
        String expected = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
                "Guess the number: The number is greater than 84\n" +
                "Guess the number: The number is greater than 85\n" +
                "Guess the number: Congratulations! You guessed the number.\n";


        System.setIn(new ByteArrayInputStream(input.getBytes()));
        GuessNumber.guessingNumberGame(rand);
        assertEquals(expected, outputStream.toString());
    }

    @Test
    public void testGuessRightFourthGuess() {
        Random rand = new Random(1); //number is 86

        String input = "87\n84\n85\n86\n";
        String expected = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
                "Guess the number: The number is less than 87\n" +
                "Guess the number: The number is greater than 84\n" +
                "Guess the number: The number is greater than 85\n" +
                "Guess the number: Congratulations! You guessed the number.\n";


        System.setIn(new ByteArrayInputStream(input.getBytes()));
        GuessNumber.guessingNumberGame(rand);
        assertEquals(expected, outputStream.toString());
    }

    @Test
    public void testGuessRightFifthGuess() {
        Random rand = new Random(1); //number is 86

        String input = "88\n87\n84\n85\n86\n";
        String expected = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
                "Guess the number: The number is less than 88\n" +
                "Guess the number: The number is less than 87\n" +
                "Guess the number: The number is greater than 84\n" +
                "Guess the number: The number is greater than 85\n" +
                "Guess the number: Congratulations! You guessed the number.\n";

        System.setIn(new ByteArrayInputStream(input.getBytes()));
        GuessNumber.guessingNumberGame(rand);
        assertEquals(expected, outputStream.toString());
    }

    @Test
    void testGuessNumberIs100() {
        String input = "88\n87\n84\n85\n100\n";

        String expected = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
                "Guess the number: The number is greater than 88\n" +
                "Guess the number: The number is greater than 87\n" +
                "Guess the number: The number is greater than 84\n" +
                "Guess the number: The number is greater than 85\n" +
                "Guess the number: Congratulations! You guessed the number.\n";

        System.setIn(new ByteArrayInputStream(input.getBytes()));

        Random rand = new Random() {
            @Override
            public int nextInt(int bound) {
                return 99;
            }
        };

        GuessNumber.guessingNumberGame(rand);
        assertEquals(expected, outputStream.toString());

    }

    @Test
    void testGuessNumberIs1() {
        String input = "88\n87\n84\n85\n1\n";

        String expected = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
                "Guess the number: The number is less than 88\n" +
                "Guess the number: The number is less than 87\n" +
                "Guess the number: The number is less than 84\n" +
                "Guess the number: The number is less than 85\n" +
                "Guess the number: Congratulations! You guessed the number.\n";

        System.setIn(new ByteArrayInputStream(input.getBytes()));

        Random rand = new Random() {
            @Override
            public int nextInt(int bound) {
                return 0;
            }
        };

        GuessNumber.guessingNumberGame(rand);
        assertEquals(expected, outputStream.toString());


    }

    @Test
    void testGuessNumberNegativeZeroInputs() {
        String input = "-1\n0\n84\n85\n1\n";

        String expected = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n" +
                "Guess the number: The number is greater than -1\n" +
                "Guess the number: The number is greater than 0\n" +
                "Guess the number: The number is less than 84\n" +
                "Guess the number: The number is less than 85\n" +
                "Guess the number: Congratulations! You guessed the number.\n";

        System.setIn(new ByteArrayInputStream(input.getBytes()));

        Random rand = new Random() {
            @Override
            public int nextInt(int bound) {
                return 0;
            }
        };

        GuessNumber.guessingNumberGame(rand);
        assertEquals(expected, outputStream.toString());


    }

    @Test
    public void testInvalidInput() {
        Random rand = new Random(1); //number is 86

        String input = "hi\n";


        System.setIn(new ByteArrayInputStream(input.getBytes()));

        try{
            GuessNumber.guessingNumberGame(rand);
            fail("did not throw exception on invalid input");

        } catch (Exception ex){


        }


    }








}
