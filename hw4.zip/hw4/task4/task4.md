https://github.com/ashley-yuanyuan/ci-helloworld

https://hub.docker.com/repository/docker/ashleyyuanyuan/ci-helloworld/general