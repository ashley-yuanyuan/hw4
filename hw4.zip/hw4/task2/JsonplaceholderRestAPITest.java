
import io.restassured.RestAssured;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class JsonplaceholderRestAPITest {

    @BeforeAll
    public static void setUp() {
        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
    }

    @Test
    public void testAlbumsContainsText() {
        given()
                .when()
                .get("/albums")
                .then()
                .assertThat()
                .body("title", hasItem("omnis laborum odio"));
    }

    @Test
    public void testCommentsAtLeast200Comments() {
        given()
                .when()
                .get("/comments")
                .then()
                .assertThat()
                .body("size()", greaterThanOrEqualTo(200));
    }

    @Test
    public void testUsersUserDetails() {
        given()
                .when()
                .get("/users")
                .then()
                .assertThat()
                .body("find { it.name == 'Ervin Howell' }.username", equalTo("Antonette"))
                .body("find { it.name == 'Ervin Howell' }.address.zipcode", equalTo("90566-7771"));
    }

    @Test
    public void testCommentsCommentsFromBizEmails() {
        given()
                .when()
                .get("/comments")
                .then()
                .assertThat()
                .body("email.findAll { it.endsWith('.biz') }", hasSize(greaterThan(0)));
    }


    @Test
    public void testCreateNewPost() {
        String requestBody = "{ " +
                "\"userId\": 11, " +
                "\"id\": 101, " +
                "\"title\": \"sunt aut facere repellat provident occaecati excepturi optio reprehenderit\", " +
                "\"body\": \"quia et suscipit\\n" +
                "suscipit recusandae consequuntur expedita et cum\\n" +
                "reprehenderit molestiae ut ut quas totam\\n" +
                "nostrum rerum est autem sunt rem eveniet architecto\" " +
                "}";

        given()
                .contentType("application/json")
                .body(requestBody)
                .when()
                .post("/posts")
                .then()
                .statusCode(201);
    }





}

